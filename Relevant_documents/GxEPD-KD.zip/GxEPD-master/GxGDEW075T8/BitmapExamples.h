#ifndef _GxBitmapExamples_H_
#define _GxBitmapExamples_H_

#if defined(ESP8266) || defined(ESP32)
#include <pgmspace.h>
#else
#include <avr/pgmspace.h>
#endif

#endif

